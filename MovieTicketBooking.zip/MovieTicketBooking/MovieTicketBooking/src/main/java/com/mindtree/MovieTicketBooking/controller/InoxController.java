package com.mindtree.MovieTicketBooking.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.MovieTicketBooking.entity.Inox;
import com.mindtree.MovieTicketBooking.service.InoxService;

import org.slf4j.Logger;
import lombok.extern.slf4j.Slf4j;
@Slf4j
@RestController
@EnableTransactionManagement
@RequestMapping("inox")
public class InoxController {
	@Autowired
	private InoxService inoxservice;
	
	private static final Logger logger = LoggerFactory.getLogger(InoxController.class);
	
	//build inox Rest Api
	//http://localhost:8080/inox/addinox
	@PostMapping("/addinox")
	public ResponseEntity<Inox> saveinox(@RequestBody Inox inox) {
		Inox savedinox=inoxservice.saveinox(inox);
		logger.debug("Successfully Created");
		return new ResponseEntity<Inox>(savedinox, HttpStatus.CREATED) ;
	}
	
	//build All inoxs Rest Api
	//http://localhost:8080/inox/addinox
	@PostMapping("/addinoxs")
	public void saveinoxs(@RequestBody List<Inox> inox) {
		logger.debug("Successfully saved all inox data");
		inoxservice.saveAll(inox);
	}
	//build get inox by using id
	//http://localhost:8080/inox/1
	@GetMapping("/{id}")
	public ResponseEntity<Inox> getinox(@PathVariable long id){
		Inox inox = inoxservice.getInox(id);
		if(inox==null) {
			logger.error("Error while getting data");
			return new ResponseEntity<Inox>(HttpStatus.NOT_FOUND);
		}
		logger.debug("successfully got all data");
		return new ResponseEntity<Inox>(inox,HttpStatus.OK);
	}
	//buid get all inoxs by using Rest api
	//http://localhost:8080/inox/allinoxs
	@GetMapping("/allinoxs")
	public List<Inox> getall(){
		logger.debug("Successfully got data");
		return inoxservice.getAllInox();
	}
	//build update inox Rest Api
	//http://localhost:8080/inox/updateinox
	@PutMapping("/updateinox")
	public ResponseEntity<Inox> updateinox(@RequestBody Inox inox) {
		Inox updateinox=inoxservice.saveinox(inox);
		if(updateinox==null) {
			logger.error("Error while updating");
			return new ResponseEntity<Inox>(HttpStatus.NOT_FOUND);
		}
		logger.debug("Successfully updated");
		return new ResponseEntity<Inox>(updateinox, HttpStatus.OK);
	}
	//build delete inox using id Rest Api
	//http://localhost:8080/inox/{id}
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteinox(@PathVariable long id) {
		inoxservice.deleteInox(id);
		return new ResponseEntity<String>("Successfully deleted",HttpStatus.OK);
		
	}
	

}
