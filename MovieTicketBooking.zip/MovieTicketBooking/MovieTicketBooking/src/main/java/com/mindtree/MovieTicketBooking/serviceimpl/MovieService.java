package com.mindtree.MovieTicketBooking.serviceimpl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.MovieTicketBooking.DTO.MovieTicketDTO;
import com.mindtree.MovieTicketBooking.entity.User;
import com.mindtree.MovieTicketBooking.repository.UserRepository;



@Service
public class MovieService {
	@Autowired
	private UserRepository userRepo;
	
	@Autowired
	private ModelMapper modelMapper;
	
	public List<MovieTicketDTO> getAllMovieDetaills(){
		return userRepo.findAll()
				       .stream()
				       .map(this::convertEntityToDto)
				       .collect(Collectors.toList());
		
	}
	
	private MovieTicketDTO convertEntityToDto(User user) {
		//configuration is used to fetch the Entire data 
		modelMapper.getConfiguration()
		                    .setMatchingStrategy(MatchingStrategies.LOOSE);
		//mapping of client to server
		MovieTicketDTO movieticketdto=new MovieTicketDTO();
		movieticketdto=modelMapper.map(user, MovieTicketDTO.class);
		return movieticketdto;
	}
	
	private User convertDtoToEntity(MovieTicketDTO movieticketDto) {
		//configuration is used to fetch the Entire data 
		modelMapper.getConfiguration()
                     .setMatchingStrategy(MatchingStrategies.LOOSE);
		//mapping of server to client
		User user = new User();
		user = modelMapper.map(movieticketDto, User.class);
		return user;
		
	}
	

}
