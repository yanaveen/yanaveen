package com.mindtree.MovieTicketBooking.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.MovieTicketBooking.entity.Inox;
import com.mindtree.MovieTicketBooking.entity.Movie;
import com.mindtree.MovieTicketBooking.service.InoxService;
import com.mindtree.MovieTicketBooking.service.MovieService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@EnableTransactionManagement
@RequestMapping("/movie")
public class MovieController {
	@Autowired
	private MovieService movieservice;
	
	private static final Logger logger = LoggerFactory.getLogger(MovieController.class);
	
	//build movie Rest Api
	//http://localhost:8080/movie/addmovie
	@PostMapping("/addmovie")
	public ResponseEntity<Movie> savemovie(@RequestBody Movie movie) {
		//save the Movie Data
		Movie savedmovie=movieservice.savemovie(movie);
		logger.debug("Successfully Created");
		return new ResponseEntity<Movie>(savedmovie, HttpStatus.CREATED);
	}
	
	//build All movies Rest Api
	//http://localhost:8080/movie/addmovies
	@PostMapping("/addmovies")
	public void savemovies(@RequestBody List<Movie> movie) {
		//Save all the data
		/* List<Movie> savedmovies=movieservice.saveallmovie(movie); */
		logger.debug("Successfully created All Movies");
		movieservice.saveallmovie(movie);
	}
	//build get movie by using id
	//http://localhost:8080/movie/{id}
	@GetMapping("/{id}")
	public ResponseEntity<Movie> getmovie(@PathVariable("id") long Id){
		Movie movie = movieservice.getmoviebyid(Id);
		if(movie==null) {
			logger.error("Id not found");
			return new ResponseEntity<Movie>(HttpStatus.NOT_FOUND);
		}
		logger.debug("Fetched the data");
		return new ResponseEntity<Movie>(movie,HttpStatus.OK);
	}
	//buid get all movies by using Rest api
	//http://localhost:8080/movie/allmovies
	@GetMapping("/allmovies")
	public ResponseEntity<List<Movie>> getallmovies(){
		logger.debug("Fetch all movies");
		return new ResponseEntity<List<Movie>>(movieservice.getallmovies(),HttpStatus.OK);
	}
	//build update movie Rest Api
	//http://localhost:8080/movie/1
	@PutMapping("/{id}")
	public ResponseEntity<Movie> updateMovie(@PathVariable("id") long Id,@RequestBody Movie movie) {
		Movie updatemovie = movieservice.updatemovie(movie, Id);
		if(updatemovie==null) {
			logger.error("Error during Update");
			return new ResponseEntity<Movie>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Movie>(updatemovie,HttpStatus.OK);
	}
	//build delete movie using id Rest Api
	//http://localhost:8080/movie/{id}
	@DeleteMapping("/{id}")
	public ResponseEntity<?> deletemovie(@PathVariable("id") long Id) {
		//delete the movie Data
		 movieservice.deletemovie(Id);
		logger.debug("Successfully Deleted");
		return new ResponseEntity<>("Successfully Deleted",HttpStatus.OK);
	}

}
