package com.mindtree.MovieTicketBooking.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.MovieTicketBooking.entity.Inox;
import com.mindtree.MovieTicketBooking.entity.PVR;
import com.mindtree.MovieTicketBooking.entity.User;
import com.mindtree.MovieTicketBooking.service.InoxService;
import com.mindtree.MovieTicketBooking.service.PvrService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@EnableTransactionManagement
@RequestMapping("/pvr")
public class PvrController {
	@Autowired
	private PvrService pvrservice;
	
	private static final Logger logger = LoggerFactory.getLogger(PvrController.class);

	// build pvr Rest Api
	// http://localhost:8080/pvr/addpvr
	@PostMapping("/addpvr")
	public ResponseEntity<PVR> savepvr(@RequestBody PVR pvr) {
		//save the data to the DB
		PVR savedpvr = pvrservice.savepvr(pvr);
		logger.debug("Successfully Created");
		/* pvrservice.savepvr(pvr); */
		return new ResponseEntity<PVR>(savedpvr, HttpStatus.CREATED);
	}

	// build All pvrs Rest Api
	// http://localhost:8080/pvr/addpvrs
	@PostMapping("/addpvrs")
	public void savepvrs(@RequestBody List<PVR> pvr) {
		//Add multiple pvr Data into DB
		logger.debug("Successfully posted the PVR data");
		pvrservice.saveAllpvr(pvr);
	}

	// build get pvr by using id
	// http://localhost:8080/pvr/{id}
	@GetMapping("/{id}")
	public ResponseEntity<PVR> getpvr(@PathVariable("id") long Id) {
		//Fetch the pvr data using pvr id from DB 
		PVR pvr= pvrservice.getpvrById(Id);
		if(pvr==null) {
			logger.error("No id Found");
			return new ResponseEntity<PVR>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<PVR>(pvr,HttpStatus.OK);
	}

	// buid get all pvr by using Rest api
	// http://localhost:8080/pvr/allpvrs
	@GetMapping("/allpvrs")
	public List<PVR> getallpvr() {
		//Get All PVR data which is present in the DB 
		logger.debug("Details fetched");
		return pvrservice.getAllpvrs();
	}

	// build update pvr Rest Api
	// http://localhost:8080/pvr/updatepvr
	@PutMapping("/{id}")
	public ResponseEntity<PVR> updatepvr(@PathVariable("{id}") long Id,
			                              @RequestBody PVR pvr) {
		//Update the DAta using Id
		PVR updatepvr=pvrservice.updatepvr(pvr, Id);
		if(updatepvr==null) {
			logger.error("Details are not updated");
			return new ResponseEntity<PVR>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		logger.debug("pvr details updated");
		return new ResponseEntity<PVR>(updatepvr,HttpStatus.OK);
	}

	// build delete pvr using id Rest Api
	// http://localhost:8080/pvr/{id}
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deletepvr(@PathVariable long id) {
		//delete PVR data from DB
		pvrservice.deletepvr(id);
		logger.debug("Successfully Deleted");
		return new ResponseEntity<String>("Successfully deleted the PVR data",HttpStatus.OK);
	}

}
