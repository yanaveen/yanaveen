package com.mindtree.MovieTicketBooking.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.MovieTicketBooking.entity.Screen;
import com.mindtree.MovieTicketBooking.exception.ResourseNotFoundException;
import com.mindtree.MovieTicketBooking.repository.ScreenRepository;
import com.mindtree.MovieTicketBooking.service.ScreenService;



@Service
@Transactional(isolation = Isolation.READ_COMMITTED,propagation = Propagation.SUPPORTS, readOnly = false, timeout = 30)
public class ScreenServiceImpl implements ScreenService {
	@Autowired
	private ScreenRepository screenRepo;

	/*
	 * //constructor type dependecy as been injected to screenserviceimplmentation
	 * calss public ScreenServiceImpl(ScreenRepository screenRepo) { super();
	 * this.screenRepo = screenRepo; }
	 */
	@Override
	public Screen savescreen(Screen screen) {
		// TODO Auto-generated method stub
		
		return screenRepo.save(screen);
	}
	@Override
	public List<Screen> saveallscreen(List<Screen> screen) {
		// TODO Auto-generated method stub
		return screenRepo.saveAll(screen);
	}
	@Override
	public List<Screen> getallscreens() {
		// TODO Auto-generated method stub
		return screenRepo.findAll();
	}

	/*
	 * @Override public Optional<Screen> getscreen(long id) { // TODO Auto-generated
	 * method stub
	 * 
	 * }
	 */
	@Override
	public void deletescreen(long id) {
		// TODO Auto-generated method stub
		screenRepo.findById(id).orElseThrow(() -> 
		            new ResourseNotFoundException("Screen", "Id", id));
		screenRepo.deleteById(id);
		
	}
	@Override
	public Screen updatescreen(Screen screen, long id) {
		// TODO Auto-generated method stub
		//we need to check wheather Screen with given id exist in DB or Not
		Screen existingScreen = screenRepo.findById(id).orElseThrow(() -> 
		                       new ResourseNotFoundException("Screen", "Id",id));
		existingScreen.setType(screen.getType());
		existingScreen.setMovie(screen.getMovie());
		//save existing screen to DB
		screenRepo.save(existingScreen);
		return existingScreen;
	}
	@Override
	public Screen getscreenById(long id) {
		return screenRepo.findById(id).orElseThrow(() -> 
		    new ResourseNotFoundException("Screen", "Id", id));
	}
	
	
	
	

}
