package com.mindtree.MovieTicketBooking.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.MovieTicketBooking.entity.Movie;
import com.mindtree.MovieTicketBooking.entity.User;
import com.mindtree.MovieTicketBooking.exception.ResourseNotFoundException;
import com.mindtree.MovieTicketBooking.repository.MovieRepository;
import com.mindtree.MovieTicketBooking.service.MovieService;



@Service
@Transactional(isolation = Isolation.READ_COMMITTED,propagation = Propagation.SUPPORTS, readOnly = false, timeout = 30)
public class MovieServiceImpl implements MovieService {
	@Autowired
	private MovieRepository movieRepo;

	/*
	 * //constructor type dependency as been injected to the
	 * movieserviceimplementation class public MovieServiceImpl(MovieRepository
	 * movieRepo) { super(); this.movieRepo = movieRepo; }
	 */
@Override
public Movie savemovie(Movie movie) {
	// TODO Auto-generated method stub
	//check wheather the data is present or not
	return movieRepo.save(movie);
	
}
@Override
public List<Movie> saveallmovie(List<Movie> movie) {
	// TODO Auto-generated method stub
	return  movieRepo.saveAll(movie);
}
@Override
public List<Movie> getallmovies() {
	// TODO Auto-generated method stub
	return movieRepo.findAll();
}

/*
 * @Override public Optional<Movie> getmoviebyid(long id) { // TODO
 * Auto-generated method stub movieRepo.findById(id).orElseThrow(() -> new
 * ResourseNotFoundException("Movie", "Id", id)); return movieRepo.findById(id);
 * }
 */
@Override
public void deletemovie(long id) {
	// TODO Auto-generated method stub
	movieRepo.findById(id).orElseThrow(() -> new ResourseNotFoundException("Movie", "Id", id));
	movieRepo.deleteById(id);
}
@Override
public Movie updatemovie(Movie movie, long id) {
	// TODO Auto-generated method stub
	//we need to check wheather Movie with given id exist in DB or not
			Movie existingMovie = movieRepo.findById(id).orElseThrow(()
					-> new ResourseNotFoundException("Movie", "Id", id));
			existingMovie.setTitle(movie.getTitle());
			existingMovie.setReleaseDate(movie.getReleaseDate());
			existingMovie.setShowcycle(movie.getShowcycle());
			//save existing user to DB
			movieRepo.save(existingMovie);
			
	return existingMovie;
}
@Override
public Movie getmoviebyid(long id) {
     return movieRepo.findById(id).orElseThrow(() ->
                   new ResourseNotFoundException("Movie", "Id", id));
}

}
