package com.mindtree.MovieTicketBooking.entity;

import java.util.List;
import java.util.Objects;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.ToString;

@Entity
@Table(name="INOX")
public class Inox implements CinemaIf,Comparable<Inox> {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	private long id;
	@OneToMany(cascade = CascadeType.ALL)
	@ToString.Exclude
	private List<Screen> screen;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public List<Screen> getScreen() {
		return screen;
	}
	public void setScreen(List<Screen> screen) {
		this.screen = screen;
	}
	public Inox() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Inox(long id, List<Screen> screen) {
		super();
		this.id = id;
		this.screen = screen;
	}
	@Override
	public int hashCode() {
		return Objects.hash(id, screen);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Inox other = (Inox) obj;
		return id == other.id && Objects.equals(screen, other.screen);
	}
	@Override
	public String toString() {
		return "Inox [id=" + id + ", screen=" + screen + "]";
	}
	@Override
	public int compareTo(Inox o) {
		// TODO Auto-generated method stub
		if(id>o.id) {
			return 1;
		}else if (Objects.equals(id, o.id)) {
			return 0;
		}else {
			return -1;
		} 
	}
	
	

}
