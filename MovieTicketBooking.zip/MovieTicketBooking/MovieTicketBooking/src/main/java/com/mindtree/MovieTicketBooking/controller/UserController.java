package com.mindtree.MovieTicketBooking.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.MovieTicketBooking.DTO.MovieTicketDTO;
import com.mindtree.MovieTicketBooking.entity.Screen;
import com.mindtree.MovieTicketBooking.entity.User;
import com.mindtree.MovieTicketBooking.service.UserService;
import com.mindtree.MovieTicketBooking.serviceimpl.MovieService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@EnableTransactionManagement
@RequestMapping("/user")
public class UserController {
	@Autowired
	private UserService userservice;
	
	@Autowired
	private MovieService movieservice;
	
	private static final Logger logger = LoggerFactory.getLogger(UserController.class);
	
	//build user Rest Api
	//http://localhost:8080/user/adduser
	@PostMapping("/adduser")
	public ResponseEntity<User> saveuser(@RequestBody User user) {
		/*
		 * User users= userservice.saveuser(user); return new ResponseEntity<>
		 * (users,HttpStatus.CREATED);
		 */
		User saveduser=userservice.saveuser(user);
		logger.debug("Successgully created");
		return new ResponseEntity<User>(saveduser, HttpStatus.CREATED);
	}
	
	//build All users Rest Api
	//http://localhost:8080/user/addusers
	@PostMapping("/addusers")
	public void saveusers(@RequestBody List<User> user) {
		logger.debug("Successfully created all User");
	userservice.saveAllUsers(user);
	}
	
	//build get user by user id
	//http://localhost:8080/user/1
	@GetMapping("/{id}")
	public ResponseEntity<User> getuserById(@PathVariable("id") long userid){
		User user=userservice.getuserById(userid);
		if (user==null) {
			logger.error("No Id Found");
			return new ResponseEntity<User>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<User>(user, HttpStatus.OK);
	}
	
	//buid get all users by using Rest api
	//http://localhost:8080/user/alluser
	@GetMapping("/alluser")
	public List<User> getallusers(){
		logger.debug("Details fetched");
		return userservice.getusers();
	}
	//build update user Rest Api
	//http://localhost:8080/user/updateuser
	@PutMapping("/{id}")
	public ResponseEntity<User> updateUser(@PathVariable("id") long id
			                               ,@RequestBody User user){
		User updateuser = userservice.updateuser(user, id);
		if(updateuser==null) {
			logger.error("Error during update");
			return new ResponseEntity<User>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		logger.debug("User Updated");
		return new ResponseEntity<User>(updateuser, HttpStatus.OK);	
	}
	//build delete user using id Rest Api
	//http://localhost:8080/user/1
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteUser(@PathVariable("id") long id){
		//delete User data from DB
		userservice.deleteUser(id);
		logger.debug("Successfully Deleted");
		return new ResponseEntity<String>("User Deleted Successfully", HttpStatus.OK);
	}
	//build get movie details Rest Api
	//http://localhost:8080/user/movieDetails
	@GetMapping("/movieDetails")
	public List<MovieTicketDTO> getAllMovieDetaills(){
		return movieservice.getAllMovieDetaills();
	}
	
	

}
